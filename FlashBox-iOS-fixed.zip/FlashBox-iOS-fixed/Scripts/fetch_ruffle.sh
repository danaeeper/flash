#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/FlashBox/Resources/Ruffle/ruffle"
mkdir -p "$DEST"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 - <<'PY' "$TMP/release.json"
import json,sys,urllib.request
url='https://api.github.com/repos/ruffle-rs/ruffle/releases/latest'
req=urllib.request.Request(url,headers={'User-Agent':'FlashBox-builder'})
with urllib.request.urlopen(req) as r: data=json.load(r)
for a in data.get('assets',[]):
    n=a['name']
    if n.endswith('-web-selfhosted.zip'):
        print(a['browser_download_url']); break
else:
    raise SystemExit('No se encontró el asset web-selfhosted.')
PY
URL="$(python3 - <<'PY' "$TMP/release.json"
import json,sys,urllib.request
url='https://api.github.com/repos/ruffle-rs/ruffle/releases/latest'
req=urllib.request.Request(url,headers={'User-Agent':'FlashBox-builder'})
with urllib.request.urlopen(req) as r: data=json.load(r)
print(next(a['browser_download_url'] for a in data['assets'] if a['name'].endswith('-web-selfhosted.zip')))
PY
)"
curl -L --fail --silent --show-error "$URL" -o "$TMP/ruffle.zip"
unzip -q "$TMP/ruffle.zip" -d "$TMP/unzip"
rm -rf "$DEST"
mkdir -p "$DEST"
cp -R "$TMP/unzip"/* "$DEST/"
echo "Ruffle instalado en $DEST"
