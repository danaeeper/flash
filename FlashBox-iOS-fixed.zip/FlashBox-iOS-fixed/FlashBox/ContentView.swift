import SwiftUI
import UniformTypeIdentifiers

struct FlashGame: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var path: String
}

struct ContentView: View {
    @State private var games: [FlashGame] = []
    @State private var showingImporter = false
    @State private var selectedGame: FlashGame?

    private let gamesKey = "FlashBox.games"

    var body: some View {
        NavigationStack {
            Group {
                if games.isEmpty {
                    ContentUnavailableView(
                        "Tu biblioteca está vacía",
                        systemImage: "gamecontroller",
                        description: Text("Importa un archivo .swf para empezar.")
                    )
                } else {
                    List {
                        ForEach(games) { game in
                            Button {
                                selectedGame = game
                            } label: {
                                Label(game.name, systemImage: "gamecontroller.fill")
                            }
                        }
                        .onDelete(perform: deleteGames)
                    }
                }
            }
            .navigationTitle("FlashBox")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showingImporter = true
                    } label: {
                        Image(systemName: "plus")
                    }
                    .accessibilityLabel("Importar juego SWF")
                }
            }
            .fileImporter(
                isPresented: $showingImporter,
                allowedContentTypes: [UTType(filenameExtension: "swf") ?? .data],
                allowsMultipleSelection: false
            ) { result in
                importSWF(result)
            }
            .sheet(item: $selectedGame) { game in
                PlayerView(game: game)
            }
            .onAppear {
                loadGames()
            }
        }
    }

    private func importSWF(_ result: Result<[URL], Error>) {
        guard case .success(let urls) = result, let sourceURL = urls.first else {
            return
        }

        let accessed = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if accessed {
                sourceURL.stopAccessingSecurityScopedResource()
            }
        }

        do {
            let fileManager = FileManager.default
            let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let gamesFolder = documents.appendingPathComponent("FlashGames", isDirectory: true)

            try fileManager.createDirectory(
                at: gamesFolder,
                withIntermediateDirectories: true
            )

            let safeName = sourceURL.lastPathComponent
            let destination = uniqueDestination(
                for: gamesFolder.appendingPathComponent(safeName)
            )

            try fileManager.copyItem(at: sourceURL, to: destination)

            let game = FlashGame(
                name: destination.deletingPathExtension().lastPathComponent,
                path: destination.path
            )

            if !games.contains(where: { $0.path == game.path }) {
                games.append(game)
                saveGames()
            }
        } catch {
            print("FlashBox import error: \(error)")
        }
    }

    private func uniqueDestination(for url: URL) -> URL {
        let fileManager = FileManager.default

        if !fileManager.fileExists(atPath: url.path) {
            return url
        }

        let base = url.deletingPathExtension().lastPathComponent
        let ext = url.pathExtension
        var index = 2

        while true {
            let candidate = url
                .deletingLastPathComponent()
                .appendingPathComponent("\(base) \(index).\(ext)")

            if !fileManager.fileExists(atPath: candidate.path) {
                return candidate
            }

            index += 1
        }
    }

    private func deleteGames(at offsets: IndexSet) {
        let fileManager = FileManager.default

        for index in offsets {
            let game = games[index]
            try? fileManager.removeItem(atPath: game.path)
        }

        games.remove(atOffsets: offsets)
        saveGames()
    }

    private func saveGames() {
        if let data = try? JSONEncoder().encode(games) {
            UserDefaults.standard.set(data, forKey: gamesKey)
        }
    }

    private func loadGames() {
        guard
            let data = UserDefaults.standard.data(forKey: gamesKey),
            let saved = try? JSONDecoder().decode([FlashGame].self, from: data)
        else {
            return
        }

        games = saved.filter {
            FileManager.default.fileExists(atPath: $0.path)
        }

        if games.count != saved.count {
            saveGames()
        }
    }
}
