import SwiftUI
import UniformTypeIdentifiers

struct FlashGame: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var relativePath: String
    var dateAdded: Date = Date()
    
    var fileURL: URL? {
        guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
        return documents.appendingPathComponent("FlashGames").appendingPathComponent(relativePath)
    }
}

struct ContentView: View {
    @State private var games: [FlashGame] = []
    @State private var showingImporter = false
    @State private var selectedGame: FlashGame?
    @State private var errorMessage: String?
    @State private var showingErrorAlert = false

    private let gamesKey = "FlashBox.games"

    var body: some View {
        NavigationStack {
            Group {
                if games.isEmpty {
                    ContentUnavailableView(
                        "Biblioteca vacía",
                        systemImage: "gamecontroller",
                        description: Text("Toca el botón + para importar un juego .swf")
                    )
                } else {
                    List {
                        ForEach(games) { game in
                            Button {
                                selectedGame = game
                            } label: {
                                HStack {
                                    Image(systemName: "play.circle.fill")
                                        .font(.title2)
                                        .foregroundColor(.orange)
                                    VStack(alignment: .leading) {
                                        Text(game.name).font(.headline).foregroundColor(.primary)
                                        Text(game.dateAdded.formatted(date: .abbreviated, time: .shortened))
                                            .font(.caption2).foregroundColor(.secondary)
                                    }
                                }
                            }
                        }
                        .onDelete(perform: deleteGames)
                    }
                }
            }
            .navigationTitle("FlashBox")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: { showingImporter = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            // AL CAMBIAR A .item, LIVECONTAINER YA NO BLOQUEARÁ EL TOQUE
            .fileImporter(
                isPresented: $showingImporter,
                allowedContentTypes: [.item],
                allowsMultipleSelection: false
            ) { result in
                importSWF(result)
            }
            .fullScreenCover(item: $selectedGame) { game in
                PlayerView(game: game)
            }
            .alert("Error de importación", isPresented: $showingErrorAlert) {
                Button("Aceptar", role: .cancel) { }
            } message: {
                Text(errorMessage ?? "Ocurrió un error desconocido.")
            }
            .onAppear(perform: loadGames)
        }
    }

    private func importSWF(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let sourceURL = urls.first else { return }
            
            // Validamos manualmente que sea un .swf ya que abrimos el selector a todos los archivos
            if sourceURL.pathExtension.lowercased() != "swf" {
                errorMessage = "Por favor, selecciona un archivo con extensión .swf válido."
                showingErrorAlert = true
                return
            }

            let accessed = sourceURL.startAccessingSecurityScopedResource()
            defer { if accessed { sourceURL.stopAccessingSecurityScopedResource() } }

            do {
                let fileManager = FileManager.default
                guard let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
                
                let gamesFolder = documents.appendingPathComponent("FlashGames", isDirectory: true)
                if !fileManager.fileExists(atPath: gamesFolder.path) {
                    try fileManager.createDirectory(at: gamesFolder, withIntermediateDirectories: true)
                }

                let safeFileName = sourceURL.lastPathComponent
                let destination = uniqueDestination(for: gamesFolder.appendingPathComponent(safeFileName))

                try fileManager.copyItem(at: sourceURL, to: destination)

                let newGame = FlashGame(
                    name: destination.deletingPathExtension().lastPathComponent,
                    relativePath: destination.lastPathComponent
                )

                games.removeAll { $0.relativePath == newGame.relativePath } 
                games.insert(newGame, at: 0)
                saveGames()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    selectedGame = newGame
                }
                
            } catch {
                errorMessage = "LiveContainer bloqueó el archivo o falló la copia: \(error.localizedDescription)"
                showingErrorAlert = true
            }
        case .failure(let error):
            errorMessage = error.localizedDescription
            showingErrorAlert = true
        }
    }

    private func uniqueDestination(for url: URL) -> URL {
        let fileManager = FileManager.default
        if !fileManager.fileExists(atPath: url.path) { return url }
        
        let base = url.deletingPathExtension().lastPathComponent
        let ext = url.pathExtension
        var index = 2
        
        while true {
            let candidate = url.deletingLastPathComponent().appendingPathComponent("\(base) \(index).\(ext)")
            if !fileManager.fileExists(atPath: candidate.path) { return candidate }
            index += 1
        }
    }

    private func deleteGames(at offsets: IndexSet) {
        for index in offsets {
            if let fileURL = games[index].fileURL {
                try? FileManager.default.removeItem(at: fileURL)
            }
        }
        games.remove(atOffsets: offsets)
        saveGames()
    }

    private func saveGames() {
        if let data = try? JSONEncoder().encode(games) {
            UserDefaults.standard.set(data, forKey: gamesKey)
        }
    }

    private func loadGames() {
        if let data = UserDefaults.standard.data(forKey: gamesKey),
           let saved = try? JSONDecoder().decode([FlashGame].self, from: data) {
            games = saved.filter { FileManager.default.fileExists(atPath: $0.fileURL?.path ?? "") }
        }
    }
}