import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct FlashGame: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var relativePath: String
    var dateAdded: Date = Date()
    
    var fileURL: URL? {
        guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
        return documents.appendingPathComponent("FlashGames").appendingPathComponent(relativePath)
    }
}

struct ContentView: View {
    @State private var games: [FlashGame] = []
    @State private var showingImporter = false
    @State private var selectedGame: FlashGame?
    @State private var errorMessage: String?
    @State private var showingErrorAlert = false

    private let gamesKey = "FlashBox.games"

    var body: some View {
        NavigationStack {
            Group {
                if games.isEmpty {
                    ContentUnavailableView(
                        "Biblioteca vacía",
                        systemImage: "gamecontroller",
                        description: Text("Toca el botón + para importar un juego .swf")
                    )
                } else {
                    List {
                        ForEach(games) { game in
                            Button {
                                selectedGame = game
                            } label: {
                                HStack {
                                    Image(systemName: "play.circle.fill")
                                        .font(.title2)
                                        .foregroundColor(.orange)
                                    VStack(alignment: .leading) {
                                        Text(game.name).font(.headline).foregroundColor(.primary)
                                        Text(game.dateAdded.formatted(date: .abbreviated, time: .shortened))
                                            .font(.caption2).foregroundColor(.secondary)
                                    }
                                }
                            }
                        }
                        .onDelete(perform: deleteGames)
                    }
                }
            }
            .navigationTitle("FlashBox")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: { showingImporter = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            // Presentamos el Document Picker con Binding para forzar su cierre
            .sheet(isPresented: $showingImporter) {
                DocumentPicker(isPresented: $showingImporter) { url in
                    importSWF(url)
                }
                .ignoresSafeArea()
            }
            .fullScreenCover(item: $selectedGame) { game in
                PlayerView(game: game)
            }
            .alert("Error de importación", isPresented: $showingErrorAlert) {
                Button("Aceptar", role: .cancel) { }
            } message: {
                Text(errorMessage ?? "Ocurrió un error desconocido.")
            }
            .onAppear(perform: loadGames)
        }
    }

    private func importSWF(_ sourceURL: URL) {
        if sourceURL.pathExtension.lowercased() != "swf" {
            errorMessage = "Por favor, selecciona un archivo con extensión .swf válido."
            showingErrorAlert = true
            return
        }

        do {
            let fileManager = FileManager.default
            guard let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
            
            let gamesFolder = documents.appendingPathComponent("FlashGames", isDirectory: true)
            if !fileManager.fileExists(atPath: gamesFolder.path) {
                try fileManager.createDirectory(at: gamesFolder, withIntermediateDirectories: true)
            }

            let safeFileName = sourceURL.lastPathComponent
            let destination = uniqueDestination(for: gamesFolder.appendingPathComponent(safeFileName))

            // Extraemos los bytes de la copia temporal de iOS sin usar permisos Security-Scoped
            let data = try Data(contentsOf: sourceURL)
            try data.write(to: destination)

            let newGame = FlashGame(
                name: destination.deletingPathExtension().lastPathComponent,
                relativePath: destination.lastPathComponent
            )

            games.removeAll { $0.relativePath == newGame.relativePath } 
            games.insert(newGame, at: 0)
            saveGames()
            
            // Auto-arranque del juego tras medio segundo
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                selectedGame = newGame
            }
            
        } catch {
            errorMessage = "Error al leer el archivo en LiveContainer: \(error.localizedDescription)"
            showingErrorAlert = true
        }
    }

    private func uniqueDestination(for url: URL) -> URL {
        let fileManager = FileManager.default
        if !fileManager.fileExists(atPath: url.path) { return url }
        
        let base = url.deletingPathExtension().lastPathComponent
        let ext = url.pathExtension
        var index = 2
        
        while true {
            let candidate = url.deletingLastPathComponent().appendingPathComponent("\(base) \(index).\(ext)")
            if !fileManager.fileExists(atPath: candidate.path) { return candidate }
            index += 1
        }
    }

    private func deleteGames(at offsets: IndexSet) {
        for index in offsets {
            if let fileURL = games[index].fileURL {
                try? FileManager.default.removeItem(at: fileURL)
            }
        }
        games.remove(atOffsets: offsets)
        saveGames()
    }

    private func saveGames() {
        if let data = try? JSONEncoder().encode(games) {
            UserDefaults.standard.set(data, forKey: gamesKey)
        }
    }

    private func loadGames() {
        if let data = UserDefaults.standard.data(forKey: gamesKey),
           let saved = try? JSONDecoder().decode([FlashGame].self, from: data) {
            games = saved.filter { FileManager.default.fileExists(atPath: $0.fileURL?.path ?? "") }
        }
    }
}

// MARK: - Wrapper Nativo Seguro para LiveContainer
struct DocumentPicker: UIViewControllerRepresentable {
    @Binding var isPresented: Bool
    var onPick: (URL) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // asCopy: true es la clave mágica. Obliga a iOS a crear un clon limpio del archivo en la carpeta tmp
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        var parent: DocumentPicker

        init(_ parent: DocumentPicker) {
            self.parent = parent
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            // Forzamos el cierre de la ventana inmediatamente al tocar
            parent.isPresented = false
            
            guard let url = urls.first else { return }
            parent.onPick(url)
        }
        
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            parent.isPresented = false
        }
    }
}