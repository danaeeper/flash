import SwiftUI
import UniformTypeIdentifiers

// MARK: - Modelo de Datos
struct FlashGame: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var relativePath: String // Guardamos solo el nombre/ruta relativa para evitar romper el Sandbox de iOS
    var dateAdded: Date = Date()
    
    // Obtiene la URL absoluta en tiempo real
    var fileURL: URL? {
        guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return nil
        }
        return documents.appendingPathComponent("FlashGames").appendingPathComponent(relativePath)
    }
}

// MARK: - Vista Principal
struct ContentView: View {
    @State private var games: [FlashGame] = []
    @State private var showingImporter = false
    @State private var selectedGame: FlashGame?
    @State private var errorMessage: String?
    @State private var showingErrorAlert = false

    private let gamesKey = "FlashBox.games"

    // Tipos de archivo permitidos para el selector
    private var allowedTypes: [UTType] {
        var types: [UTType] = [.data]
        if let swfType = UTType(filenameExtension: "swf") {
            types.insert(swfType, at: 0)
        }
        if let mimeType = UTType(mimeType: "application/x-shockwave-flash") {
            types.insert(mimeType, at: 0)
        }
        return types
    }

    var body: some View {
        NavigationStack {
            Group {
                if games.isEmpty {
                    ContentUnavailableView(
                        "Tu biblioteca está vacía",
                        systemImage: "gamecontroller",
                        description: Text("Importa un archivo .swf para empezar a jugar.")
                    )
                } else {
                    List {
                        ForEach(games) { game in
                            Button {
                                selectedGame = game
                            } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: "play.circle.fill")
                                        .font(.title2)
                                        .foregroundColor(.orange)
                                    
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(game.name)
                                            .font(.headline)
                                            .foregroundColor(.primary)
                                        Text(game.dateAdded.formatted(date: .abbreviated, time: .shortened))
                                            .font(.caption2)
                                            .foregroundColor(.secondary)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        }
                        .onDelete(perform: deleteGames)
                    }
                }
            }
            .navigationTitle("FlashBox")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showingImporter = true
                    } label: {
                        Image(systemName: "plus")
                    }
                    .accessibilityLabel("Importar juego SWF")
                }
            }
            .fileImporter(
                isPresented: $showingImporter,
                allowedContentTypes: allowedTypes,
                allowsMultipleSelection: false
            ) { result in
                importSWF(result)
            }
            .fullScreenCover(item: $selectedGame) { game in
                PlayerView(game: game)
            }
            .alert("Error de importación", isPresented: $showingErrorAlert) {
                Button("Aceptar", role: .cancel) { }
            } message: {
                Text(errorMessage ?? "Ocurrió un error desconocido al importar.")
            }
            .onAppear {
                loadGames()
            }
        }
    }

    // MARK: - Importación y Manejo de Sandbox
    private func importSWF(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let sourceURL = urls.first else { return }

            // 1. Solicitar acceso de seguridad al archivo fuera del sandbox
            guard sourceURL.startAccessingSecurityScopedResource() else {
                errorMessage = "iOS bloqueó el acceso de lectura al archivo. Intenta moverlo a 'En mi iPhone' primero."
                showingErrorAlert = true
                return
            }
            defer {
                sourceURL.stopAccessingSecurityScopedResource()
            }

            do {
                let fileManager = FileManager.default
                guard let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else {
                    throw NSError(domain: "FlashBox", code: 1, userInfo: [NSLocalizedDescriptionKey: "Directorio de documentos inaccesible."])
                }
                
                let gamesFolder = documents.appendingPathComponent("FlashGames", isDirectory: true)

                // Asegurar que la carpeta FlashGames exista
                if !fileManager.fileExists(atPath: gamesFolder.path) {
                    try fileManager.createDirectory(at: gamesFolder, withIntermediateDirectories: true)
                }

                let safeFileName = sourceURL.lastPathComponent
                let destination = uniqueDestination(for: gamesFolder.appendingPathComponent(safeFileName))

                // Copiar el archivo al almacenamiento interno local de la app
                try fileManager.copyItem(at: sourceURL, to: destination)

                let cleanName = destination.deletingPathExtension().lastPathComponent
                let newGame = FlashGame(
                    name: cleanName,
                    relativePath: destination.lastPathComponent,
                    dateAdded: Date()
                )

                // Evitar duplicados por nombre de archivo
                games.removeAll { $0.relativePath == newGame.relativePath }
                games.insert(newGame, at: 0)
                saveGames()
                
            } catch {
                errorMessage = "No se pudo copiar el archivo SWF: \(error.localizedDescription)"
                showingErrorAlert = true
            }

        case .failure(let error):
            errorMessage = error.localizedDescription
            showingErrorAlert = true
        }
    }

    // Genera un nombre único si ya existe uno igual (ej: "Juego 2.swf")
    private func uniqueDestination(for url: URL) -> URL {
        let fileManager = FileManager.default
        if !fileManager.fileExists(atPath: url.path) {
            return url
        }

        let base = url.deletingPathExtension().lastPathComponent
        let ext = url.pathExtension
        var index = 2

        while true {
            let candidate = url.deletingLastPathComponent().appendingPathComponent("\(base) \(index).\(ext)")
            if !fileManager.fileExists(atPath: candidate.path) {
                return candidate
            }
            index += 1
        }
    }

    // MARK: - Persistencia
    private func deleteGames(at offsets: IndexSet) {
        let fileManager = FileManager.default

        for index in offsets {
            let game = games[index]
            if let fileURL = game.fileURL {
                try? fileManager.removeItem(at: fileURL)
            }
        }

        games.remove(atOffsets: offsets)
        saveGames()
    }

    private func saveGames() {
        if let data = try? JSONEncoder().encode(games) {
            UserDefaults.standard.set(data, forKey: gamesKey)
        }
    }

    private func loadGames() {
        guard
            let data = UserDefaults.standard.data(forKey: gamesKey),
            let saved = try? JSONDecoder().decode([FlashGame].self, from: data)
        else {
            return
        }

        // Filtra únicamente los juegos cuyos archivos sigan existiendo en el disco
        games = saved.filter { game in
            guard let url = game.fileURL else { return false }
            return FileManager.default.fileExists(atPath: url.path)
        }

        if games.count != saved.count {
            saveGames()
        }
    }
}