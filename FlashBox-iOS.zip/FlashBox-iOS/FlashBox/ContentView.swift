name: FlashBox
options:
  bundleIdPrefix: com.catita
settings:
  base:
    SWIFT_VERSION: 5.9
targets:
  FlashBox:
    type: application
    platform: iOS
    deploymentTarget: "17.0"
    sources:
      - path: FlashBox
    settings:
      base:
        PRODUCT_BUNDLE_IDENTIFIER: com.catita.flashbox
        INFOPLIST_KEY_CFBundleDisplayName: FlashBox
        INFOPLIST_KEY_LSApplicationCategoryType: public.app-category.games
    info:
      path: FlashBox/Info.plist
      properties:
        UILaunchScreen: {}
        UIFileSharingEnabled: true
        LSSupportsOpeningDocumentsInPlace: true
        UISupportsDocumentBrowser: true
        UTImportedTypeDeclarations:
          - UTTypeIdentifier: "com.adobe.flash.swf"
            UTTypeDescription: "Shockwave Flash Movie"
            UTTypeConformsTo:
              - "public.data"
            UTTypeTagSpecification:
              public.filename-extension:
                - "swf"
              public.mime-type:
                - "application/x-shockwave-flash"
        CFBundleDocumentTypes:
          - CFBundleTypeName: "Shockwave Flash Movie"
            CFBundleTypeRole: Viewer
            LSHandlerRank: Owner
            LSItemContentTypes:
              - "com.adobe.flash.swf"