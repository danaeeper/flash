import SwiftUI
import UniformTypeIdentifiers

struct FlashGame: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var path: String
}

struct ContentView: View {
    @State private var games: [FlashGame] = []
    @State private var showingImporter = false
    @State private var selectedGame: FlashGame?

    var body: some View {
        NavigationStack {
            Group {
                if games.isEmpty {
                    ContentUnavailableView("Tu biblioteca está vacía", systemImage: "gamecontroller", description: Text("Importa un archivo .swf para empezar."))
                } else {
                    List {
                        ForEach(games) { game in
                            Button {
                                selectedGame = game
                            } label: {
                                Label(game.name, systemImage: "gamecontroller.fill")
                            }
                        }
                        .onDelete { games.remove(atOffsets: $0) }
                    }
                }
            }
            .navigationTitle("FlashBox")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingImporter = true } label: { Image(systemName: "plus") }
                }
            }
            .fileImporter(isPresented: $showingImporter,
                          allowedContentTypes: [UTType(filenameExtension: "swf") ?? .data],
                          allowsMultipleSelection: false) { result in
                guard case .success(let urls) = result, let url = urls.first else { return }
                let accessed = url.startAccessingSecurityScopedResource()
                defer { if accessed { url.stopAccessingSecurityScopedResource() } }
                let game = FlashGame(name: url.deletingPathExtension().lastPathComponent, path: url.path)
                if !games.contains(where: { $0.path == game.path }) { games.append(game) }
            }
            .sheet(item: $selectedGame) { game in
                PlayerView(game: game)
            }
        }
    }
}
