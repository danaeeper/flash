import SwiftUI
import WebKit

struct PlayerView: View {
    let game: FlashGame
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            RufflePlayerView(swfPath: game.path)
                .ignoresSafeArea(edges: .bottom)
                .navigationTitle(game.name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("Cerrar") { dismiss() }
                    }
                }
        }
    }
}

struct RufflePlayerView: UIViewRepresentable {
    let swfPath: String

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.isOpaque = false
        web.backgroundColor = .black
        let htmlURL = Bundle.main.url(forResource: "player", withExtension: "html", subdirectory: "Ruffle")!
        web.loadFileURL(htmlURL, allowingReadAccessTo: URL(fileURLWithPath: swfPath).deletingLastPathComponent())
        context.coordinator.webView = web
        context.coordinator.swfPath = swfPath
        return web
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        guard let path = context.coordinator.swfPath,
              let data = try? Data(contentsOf: URL(fileURLWithPath: path)) else { return }
        let b64 = data.base64EncodedString()
        let js = "window.loadFlashBase64 && window.loadFlashBase64('" + b64 + "');"
        webView.evaluateJavaScript(js)
    }

    final class Coordinator {
        weak var webView: WKWebView?
        var swfPath: String?
    }
}
