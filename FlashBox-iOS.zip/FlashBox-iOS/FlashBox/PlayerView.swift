import SwiftUI
import WebKit
import UniformTypeIdentifiers

struct PlayerView: View {
    let game: FlashGame
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if let url = game.fileURL {
                    RufflePlayerView(swfURL: url)
                        .ignoresSafeArea(edges: .bottom)
                } else {
                    ContentUnavailableView(
                        "Error de archivo",
                        systemImage: "exclamationmark.triangle",
                        description: Text("No se pudo localizar el archivo del juego.")
                    )
                }
            }
            .navigationTitle(game.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cerrar") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Reproductor con Custom Scheme
struct RufflePlayerView: UIViewRepresentable {
    let swfURL: URL

    func makeCoordinator() -> Coordinator {
        Coordinator(swfURL: swfURL)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        // Magia: Registramos nuestro propio "servidor local" para evadir el error de file://
        let handler = LocalSchemeHandler()
        config.setURLSchemeHandler(handler, forURLScheme: "flashbox")

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.isScrollEnabled = false

        // Cargamos Ruffle usando nuestro protocolo personalizado en lugar de file://
        if let url = URL(string: "flashbox://localhost/player.html") {
            web.load(URLRequest(url: url))
        }

        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        let swfURL: URL

        init(swfURL: URL) {
            self.swfURL = swfURL
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            do {
                let data = try Data(contentsOf: swfURL)
                let b64 = data.base64EncodedString()
                let js = "window.loadFlashBase64 && window.loadFlashBase64('\(b64)');"
                webView.evaluateJavaScript(js)
            } catch {
                print("Error al leer el SWF: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - Manejador del Servidor Falso (Evade bloqueos CORS)
class LocalSchemeHandler: NSObject, WKURLSchemeHandler {
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else { return }
        
        let fileName = url.lastPathComponent
        var fileURL: URL?

        // Busca el archivo solicitado (player.html, ruffle.js, .wasm) en las carpetas del proyecto
        if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Resources/Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil) {
            fileURL = bundleURL
        }

        if let validFileURL = fileURL, let data = try? Data(contentsOf: validFileURL) {
            let mimeType = UTType(filenameExtension: validFileURL.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            // Forzamos el mime-type correcto para WebAssembly, vital para que Ruffle arranque
            let finalMimeType = validFileURL.pathExtension.lowercased() == "wasm" ? "application/wasm" : mimeType

            let response = HTTPURLResponse(
                url: url,
                statusCode: 200,
                httpVersion: nil,
                headerFields: [
                    "Content-Type": finalMimeType,
                    "Access-Control-Allow-Origin": "*"
                ]
            )!

            urlSchemeTask.didReceive(response)
            urlSchemeTask.didReceive(data)
            urlSchemeTask.didFinish()
        } else {
            let response = HTTPURLResponse(url: url, statusCode: 404, httpVersion: nil, headerFields: nil)!
            urlSchemeTask.didReceive(response)
            urlSchemeTask.didFinish()
        }
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        // No se requiere acción al detener la tarea
    }
}