import SwiftUI
import WebKit
import UniformTypeIdentifiers

// MARK: - Controlador del Emulador
class PlayerController: ObservableObject {
    weak var webView: WKWebView?

    func simulateKey(key: String, code: String, keyCode: Int, isDown: Bool) {
        let eventType = isDown ? "keydown" : "keyup"
        let js = """
        var e = new KeyboardEvent('\(eventType)', {
            bubbles: true, cancelable: true,
            key: '\(key)', code: '\(code)', keyCode: \(keyCode), which: \(keyCode)
        });
        window.dispatchEvent(e);
        """
        webView?.evaluateJavaScript(js)
    }
}

// MARK: - Vista Principal del Reproductor
struct PlayerView: View {
    let game: FlashGame
    @Environment(\.dismiss) private var dismiss
    
    @State private var showGamepad = false
    @StateObject private var controller = PlayerController()

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if let url = game.fileURL {
                RufflePlayerView(swfURL: url, controller: controller)
                    .ignoresSafeArea()
            } else {
                ContentUnavailableView(
                    "Error",
                    systemImage: "exclamationmark.triangle",
                    description: Text("No se encontró el archivo.")
                )
            }
            
            if showGamepad {
                GamepadOverlay(controller: controller)
            }
            
            // Botón Cerrar (Arriba Izquierda) totalmente transparente
            VStack {
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white.opacity(0.4)) // Solo el icono semi-transparente
                            .padding(20) // Área táctil amplia
                            .contentShape(Rectangle()) // Garantiza que detecte el toque sin tener fondo
                    }
                    Spacer()
                }
                Spacer()
            }
            
            // Botón Gamepad (Abajo Izquierda) totalmente transparente
            VStack {
                Spacer()
                HStack {
                    Button(action: { 
                        withAnimation { showGamepad.toggle() } 
                    }) {
                        Image(systemName: showGamepad ? "gamecontroller.fill" : "gamecontroller")
                            .font(.system(size: 26, weight: .bold))
                            // Verde tenue si está activo, blanco tenue si está inactivo
                            .foregroundColor(showGamepad ? .green.opacity(0.6) : .white.opacity(0.4))
                            .padding(20)
                            .contentShape(Rectangle())
                    }
                    Spacer()
                }
            }
        }
        .persistentSystemOverlays(.hidden)
        .onAppear {
            if #available(iOS 16.0, *) {
                guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
                windowScene.requestGeometryUpdate(.iOS(interfaceOrientations: .landscape))
            }
        }
        .onDisappear {
            if #available(iOS 16.0, *) {
                guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
                windowScene.requestGeometryUpdate(.iOS(interfaceOrientations: .portrait))
            }
        }
    }
}

// MARK: - Gamepad Infalible con UUID (VERSIÓN PRO)
struct GamepadOverlay: View {
    @ObservedObject var controller: PlayerController
    
    @State private var opacity: Double = 0.6
    @State private var timerID: UUID = UUID() // Sistema 100% seguro para SwiftUI
    @State private var useWASD = false // Alternador Flechas / WASD
    
    var body: some View {
        VStack {
            // Fila Superior (Utilidades: Pausa y Mute)
            HStack {
                Spacer()
                GameButton(text: "P", key: "p", code: "KeyP", keyCode: 80, controller: controller, width: 45, notifyInteraction: resetTimer)
                GameButton(text: "M", key: "m", code: "KeyM", keyCode: 77, controller: controller, width: 45, notifyInteraction: resetTimer)
            }
            .padding(.trailing, 50)
            .padding(.top, 20)
            
            Spacer()
            
            HStack(alignment: .bottom) {
                // MANDO IZQUIERDO: Dirección y Switch WASD
                VStack(spacing: 8) {
                    // Botón para cambiar entre Flechas y WASD
                    Button(action: {
                        useWASD.toggle()
                        resetTimer()
                    }) {
                        Text(useWASD ? "USANDO WASD" : "USANDO FLECHAS")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(Color.white.opacity(0.6))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Capsule().stroke(Color.white.opacity(0.3), lineWidth: 1))
                    }
                    .padding(.bottom, 5)
                    
                    // Botones de dirección dinámicos (Cambian entre flechas y letras)
                    GameButton(icon: useWASD ? nil : "arrowup", text: useWASD ? "W" : nil, key: useWASD ? "w" : "ArrowUp", code: useWASD ? "KeyW" : "ArrowUp", keyCode: useWASD ? 87 : 38, controller: controller, notifyInteraction: resetTimer)
                    HStack(spacing: 35) {
                        GameButton(icon: useWASD ? nil : "arrowleft", text: useWASD ? "A" : nil, key: useWASD ? "a" : "ArrowLeft", code: useWASD ? "KeyA" : "ArrowLeft", keyCode: useWASD ? 65 : 37, controller: controller, notifyInteraction: resetTimer)
                        GameButton(icon: useWASD ? nil : "arrowright", text: useWASD ? "D" : nil, key: useWASD ? "d" : "ArrowRight", code: useWASD ? "KeyD" : "ArrowRight", keyCode: useWASD ? 68 : 39, controller: controller, notifyInteraction: resetTimer)
                    }
                    GameButton(icon: useWASD ? nil : "arrowdown", text: useWASD ? "S" : nil, key: useWASD ? "s" : "ArrowDown", code: useWASD ? "KeyS" : "ArrowDown", keyCode: useWASD ? 83 : 40, controller: controller, notifyInteraction: resetTimer)
                }
                .padding(.leading, 60)
                .padding(.bottom, 30)
                
                Spacer()
                
                // MANDO DERECHO: Cluster de Acción Expandido
                VStack(spacing: 12) {
                    // Fila superior de acciones (Z, X, C)
                    HStack(spacing: 12) {
                        GameButton(text: "Z", key: "z", code: "KeyZ", keyCode: 90, controller: controller, width: 50, notifyInteraction: resetTimer)
                        GameButton(text: "X", key: "x", code: "KeyX", keyCode: 88, controller: controller, width: 50, notifyInteraction: resetTimer)
                        GameButton(text: "C", key: "c", code: "KeyC", keyCode: 67, controller: controller, width: 50, notifyInteraction: resetTimer)
                    }
                    // Fila inferior de acciones (SHIFT, SPACE, ENTER)
                    HStack(spacing: 12) {
                        GameButton(text: "SHF", key: "Shift", code: "ShiftLeft", keyCode: 16, controller: controller, width: 60, notifyInteraction: resetTimer)
                        GameButton(text: "SPC", key: " ", code: "Space", keyCode: 32, controller: controller, width: 80, notifyInteraction: resetTimer)
                        GameButton(text: "ENT", key: "Enter", code: "Enter", keyCode: 13, controller: controller, width: 60, notifyInteraction: resetTimer)
                    }
                }
                .padding(.trailing, 50)
                .padding(.bottom, 30)
            }
        }
        .opacity(opacity)
        .onAppear { resetTimer() }
    }
    
    func resetTimer() {
        withAnimation(.easeOut(duration: 0.2)) { opacity = 0.6 } 
        
        let currentID = UUID()
        timerID = currentID
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            // Si el ID no ha cambiado en 3 segundos, lo oculta sí o sí
            if self.timerID == currentID {
                withAnimation(.easeInOut(duration: 1.5)) {
                    self.opacity = 0.03
                }
            }
        }
    }
}

// MARK: - Botones del Gamepad
struct GameButton: View {
    var icon: String? = nil
    var text: String? = nil
    let key: String
    let code: String
    let keyCode: Int
    @ObservedObject var controller: PlayerController
    var width: CGFloat = 60
    var notifyInteraction: () -> Void
    
    @State private var isPressed = false
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18)
                .fill(isPressed ? Color.white.opacity(0.2) : Color.white.opacity(0.02))
                .frame(width: width, height: 60)
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.15), lineWidth: 1.5))
            
            if let icon = icon {
                Image(systemName: icon).foregroundColor(Color.white.opacity(0.5)).font(.title2)
            } else if let text = text {
                Text(text).foregroundColor(Color.white.opacity(0.5)).font(.headline)
            }
        }
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    notifyInteraction()
                    if !isPressed {
                        isPressed = true
                        controller.simulateKey(key: key, code: code, keyCode: keyCode, isDown: true)
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    }
                }
                .onEnded { _ in
                    notifyInteraction()
                    isPressed = false
                    controller.simulateKey(key: key, code: code, keyCode: keyCode, isDown: false)
                }
        )
    }
}

// MARK: - Reproductor con Custom Scheme
struct RufflePlayerView: UIViewRepresentable {
    let swfURL: URL
    @ObservedObject var controller: PlayerController

    func makeCoordinator() -> Coordinator {
        Coordinator(swfURL: swfURL)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let handler = LocalSchemeHandler()
        config.setURLSchemeHandler(handler, forURLScheme: "flashbox")

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.isScrollEnabled = false
        web.scrollView.bounces = false 
        // Permite que la web toque los bordes físicos de la pantalla
        web.scrollView.contentInsetAdjustmentBehavior = .never 

        controller.webView = web

        if let url = URL(string: "flashbox://localhost/player.html") {
            web.load(URLRequest(url: url))
        }

        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        let swfURL: URL

        init(swfURL: URL) {
            self.swfURL = swfURL
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            do {
                // Inyectamos CSS, Meta Tags y Configuración de Ruffle para tamaño MAXIMO
                let jsSetup = """
                var meta = document.createElement('meta');
                meta.name = 'viewport';
                meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover';
                document.head.appendChild(meta);

                var style = document.createElement('style');
                style.innerHTML = 'body, html { margin: 0; padding: 0; width: 100vw; height: 100vh; overflow: hidden; background-color: black; } ruffle-player { width: 100vw !important; height: 100vh !important; display: block; }';
                document.head.appendChild(style);

                window.RufflePlayer = window.RufflePlayer || {};
                window.RufflePlayer.config = {
                    letterbox: "on",
                    scale: "exactFit" 
                };
                """
                webView.evaluateJavaScript(jsSetup)

                let data = try Data(contentsOf: swfURL)
                let b64 = data.base64EncodedString()
                let js = "window.loadFlashBase64 && window.loadFlashBase64('\(b64)');"
                webView.evaluateJavaScript(js)
            } catch {
                print("Error al leer el SWF: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - Manejador del Servidor Falso
class LocalSchemeHandler: NSObject, WKURLSchemeHandler {
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else { return }
        let fileName = url.lastPathComponent
        var fileURL: URL?

        if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Resources/Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil) {
            fileURL = bundleURL
        }

        if let validFileURL = fileURL, let data = try? Data(contentsOf: validFileURL) {
            let mimeType = UTType(filenameExtension: validFileURL.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            let finalMimeType = validFileURL.pathExtension.lowercased() == "wasm" ? "application/wasm" : mimeType

            let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type": finalMimeType, "Access-Control-Allow-Origin": "*"])!
            urlSchemeTask.didReceive(response)
            urlSchemeTask.didReceive(data)
            urlSchemeTask.didFinish()
        } else {
            let response = HTTPURLResponse(url: url, statusCode: 404, httpVersion: nil, headerFields: nil)!
            urlSchemeTask.didReceive(response)
            urlSchemeTask.didFinish()
        }
    }
    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) { }
}