import SwiftUI
import WebKit
import UniformTypeIdentifiers

struct PlayerView: View {
    let game: FlashGame
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            // 1. Fondo negro total
            Color.black.ignoresSafeArea()
            
            // 2. Reproductor ignorando los bordes seguros (pantalla completa real)
            if let url = game.fileURL {
                RufflePlayerView(swfURL: url)
                    .ignoresSafeArea()
            } else {
                ContentUnavailableView(
                    "Error de archivo",
                    systemImage: "exclamationmark.triangle",
                    description: Text("No se pudo localizar el archivo del juego.")
                )
            }
            
            // 3. Botón flotante para salir (esquina superior izquierda)
            VStack {
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(12)
                            .background(Circle().fill(Color.black.opacity(0.5)))
                    }
                    .padding(.leading, 20)
                    .padding(.top, 10)
                    
                    Spacer()
                }
                Spacer()
            }
        }
        // Oculta la barra blanca de inicio del iPhone para mayor inmersión
        .persistentSystemOverlays(.hidden) 
    }
}

// MARK: - Reproductor con Custom Scheme
struct RufflePlayerView: UIViewRepresentable {
    let swfURL: URL

    func makeCoordinator() -> Coordinator {
        Coordinator(swfURL: swfURL)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let handler = LocalSchemeHandler()
        config.setURLSchemeHandler(handler, forURLScheme: "flashbox")

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.isScrollEnabled = false
        // Evita que el usuario haga zoom por accidente
        web.scrollView.bounces = false 

        if let url = URL(string: "flashbox://localhost/player.html") {
            web.load(URLRequest(url: url))
        }

        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        let swfURL: URL

        init(swfURL: URL) {
            self.swfURL = swfURL
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            do {
                // 4. Inyectamos CSS para forzar que el webview no tenga márgenes internos
                let cssJS = "var style = document.createElement('style'); style.innerHTML = 'body, html { margin: 0; padding: 0; width: 100vw; height: 100vh; overflow: hidden; background-color: black; }'; document.head.appendChild(style);"
                webView.evaluateJavaScript(cssJS)

                let data = try Data(contentsOf: swfURL)
                let b64 = data.base64EncodedString()
                let js = "window.loadFlashBase64 && window.loadFlashBase64('\(b64)');"
                webView.evaluateJavaScript(js)
            } catch {
                print("Error al leer el SWF: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - Manejador del Servidor Falso (Evade bloqueos CORS)
class LocalSchemeHandler: NSObject, WKURLSchemeHandler {
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else { return }
        
        let fileName = url.lastPathComponent
        var fileURL: URL?

        if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Resources/Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil) {
            fileURL = bundleURL
        }

        if let validFileURL = fileURL, let data = try? Data(contentsOf: validFileURL) {
            let mimeType = UTType(filenameExtension: validFileURL.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            let finalMimeType = validFileURL.pathExtension.lowercased() == "wasm" ? "application/wasm" : mimeType

            let response = HTTPURLResponse(
                url: url,
                statusCode: 200,
                httpVersion: nil,
                headerFields: [
                    "Content-Type": finalMimeType,
                    "Access-Control-Allow-Origin": "*"
                ]
            )!

            urlSchemeTask.didReceive(response)
            urlSchemeTask.didReceive(data)
            urlSchemeTask.didFinish()
        } else {
            let response = HTTPURLResponse(url: url, statusCode: 404, httpVersion: nil, headerFields: nil)!
            urlSchemeTask.didReceive(response)
            urlSchemeTask.didFinish()
        }
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) { }
}