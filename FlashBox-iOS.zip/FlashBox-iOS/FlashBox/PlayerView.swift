import SwiftUI
import WebKit
import UniformTypeIdentifiers

// MARK: - Controlador del Emulador (Puente SwiftUI -> JavaScript)
class PlayerController: ObservableObject {
    weak var webView: WKWebView?

    // Finge presionar o soltar una tecla de PC enviando un evento al navegador interno
    func simulateKey(key: String, code: String, keyCode: Int, isDown: Bool) {
        let eventType = isDown ? "keydown" : "keyup"
        let js = """
        var e = new KeyboardEvent('\(eventType)', {
            bubbles: true, cancelable: true,
            key: '\(key)', code: '\(code)', keyCode: \(keyCode), which: \(keyCode)
        });
        window.dispatchEvent(e);
        """
        webView?.evaluateJavaScript(js)
    }
}

struct PlayerView: View {
    let game: FlashGame
    @Environment(\.dismiss) private var dismiss
    
    // Estado para mostrar u ocultar el mando
    @State private var showGamepad = false
    @StateObject private var controller = PlayerController()

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if let url = game.fileURL {
                RufflePlayerView(swfURL: url, controller: controller)
                    .ignoresSafeArea()
            } else {
                ContentUnavailableView(
                    "Error de archivo",
                    systemImage: "exclamationmark.triangle",
                    description: Text("No se pudo localizar el archivo del juego.")
                )
            }
            
            // Capa del Gamepad Virtual
            if showGamepad {
                GamepadOverlay(controller: controller)
                    .transition(.opacity)
            }
            
            // Barra superior de botones flotantes
            VStack {
                HStack(spacing: 15) {
                    // Botón Cerrar
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(12)
                            .background(Circle().fill(Color.black.opacity(0.5)))
                    }
                    
                    // Botón Activar/Desactivar Gamepad
                    Button(action: { 
                        withAnimation { showGamepad.toggle() } 
                    }) {
                        Image(systemName: showGamepad ? "gamecontroller.fill" : "gamecontroller")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(showGamepad ? .green : .white)
                            .padding(12)
                            .background(Circle().fill(Color.black.opacity(0.5)))
                    }
                    
                    Spacer()
                }
                .padding(.leading, 20)
                .padding(.top, 10)
                
                Spacer()
            }
        }
        .persistentSystemOverlays(.hidden)
    }
}

// MARK: - Diseño del Gamepad Transparente
struct GamepadOverlay: View {
    @ObservedObject var controller: PlayerController
    
    var body: some View {
        VStack {
            Spacer()
            HStack {
                // Cruceta Direccional (Izquierda)
                VStack(spacing: 5) {
                    GameButton(icon: "arrowtriangle.up.fill", key: "ArrowUp", code: "ArrowUp", keyCode: 38, controller: controller)
                    HStack(spacing: 35) {
                        GameButton(icon: "arrowtriangle.left.fill", key: "ArrowLeft", code: "ArrowLeft", keyCode: 37, controller: controller)
                        GameButton(icon: "arrowtriangle.right.fill", key: "ArrowRight", code: "ArrowRight", keyCode: 39, controller: controller)
                    }
                    GameButton(icon: "arrowtriangle.down.fill", key: "ArrowDown", code: "ArrowDown", keyCode: 40, controller: controller)
                }
                .padding(.leading, 30)
                .padding(.bottom, 30)
                
                Spacer()
                
                // Botones de Acción (Derecha)
                HStack(spacing: 15) {
                    GameButton(text: "ESPACIO", key: " ", code: "Space", keyCode: 32, controller: controller, width: 90)
                    GameButton(text: "ENTER", key: "Enter", code: "Enter", keyCode: 13, controller: controller, width: 70)
                }
                .padding(.trailing, 30)
                .padding(.bottom, 30)
            }
        }
    }
}

// MARK: - Botón Individual del Gamepad
struct GameButton: View {
    var icon: String? = nil
    var text: String? = nil
    let key: String
    let code: String
    let keyCode: Int
    @ObservedObject var controller: PlayerController
    var width: CGFloat = 50
    
    @State private var isPressed = false
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .fill(isPressed ? Color.white.opacity(0.5) : Color.black.opacity(0.4))
                .frame(width: width, height: 50)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(Color.white.opacity(0.6), lineWidth: 2)
                )
            
            if let icon = icon {
                Image(systemName: icon).foregroundColor(.white).font(.title2)
            } else if let text = text {
                Text(text).foregroundColor(.white).font(.headline)
            }
        }
        // Detecta exactamente cuándo el dedo toca y cuándo suelta la pantalla
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    if !isPressed {
                        isPressed = true
                        controller.simulateKey(key: key, code: code, keyCode: keyCode, isDown: true)
                    }
                }
                .onEnded { _ in
                    isPressed = false
                    controller.simulateKey(key: key, code: code, keyCode: keyCode, isDown: false)
                }
        )
    }
}

// MARK: - Reproductor con Custom Scheme
struct RufflePlayerView: UIViewRepresentable {
    let swfURL: URL
    @ObservedObject var controller: PlayerController

    func makeCoordinator() -> Coordinator {
        Coordinator(swfURL: swfURL)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let handler = LocalSchemeHandler()
        config.setURLSchemeHandler(handler, forURLScheme: "flashbox")

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.isScrollEnabled = false
        web.scrollView.bounces = false 

        // Enlazamos la vista web al controlador para poder enviarle los toques
        controller.webView = web

        if let url = URL(string: "flashbox://localhost/player.html") {
            web.load(URLRequest(url: url))
        }

        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        let swfURL: URL

        init(swfURL: URL) {
            self.swfURL = swfURL
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            do {
                let cssJS = "var style = document.createElement('style'); style.innerHTML = 'body, html { margin: 0; padding: 0; width: 100vw; height: 100vh; overflow: hidden; background-color: black; }'; document.head.appendChild(style);"
                webView.evaluateJavaScript(cssJS)

                let data = try Data(contentsOf: swfURL)
                let b64 = data.base64EncodedString()
                let js = "window.loadFlashBase64 && window.loadFlashBase64('\(b64)');"
                webView.evaluateJavaScript(js)
            } catch {
                print("Error al leer el SWF: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - Manejador del Servidor Falso
class LocalSchemeHandler: NSObject, WKURLSchemeHandler {
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else { return }
        let fileName = url.lastPathComponent
        var fileURL: URL?

        if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Resources/Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil) {
            fileURL = bundleURL
        }

        if let validFileURL = fileURL, let data = try? Data(contentsOf: validFileURL) {
            let mimeType = UTType(filenameExtension: validFileURL.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            let finalMimeType = validFileURL.pathExtension.lowercased() == "wasm" ? "application/wasm" : mimeType

            let response = HTTPURLResponse(
                url: url, statusCode: 200, httpVersion: nil,
                headerFields: ["Content-Type": finalMimeType, "Access-Control-Allow-Origin": "*"]
            )!
            urlSchemeTask.didReceive(response)
            urlSchemeTask.didReceive(data)
            urlSchemeTask.didFinish()
        } else {
            let response = HTTPURLResponse(url: url, statusCode: 404, httpVersion: nil, headerFields: nil)!
            urlSchemeTask.didReceive(response)
            urlSchemeTask.didFinish()
        }
    }
    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) { }
}