import SwiftUI
import WebKit
import UniformTypeIdentifiers

// MARK: - Controlador del Emulador
class PlayerController: ObservableObject {
    weak var webView: WKWebView?

    func simulateKey(key: String, code: String, keyCode: Int, isDown: Bool) {
        let eventType = isDown ? "keydown" : "keyup"
        let js = """
        var e = new KeyboardEvent('\(eventType)', {
            bubbles: true, cancelable: true,
            key: '\(key)', code: '\(code)', keyCode: \(keyCode), which: \(keyCode)
        });
        window.dispatchEvent(e);
        """
        webView?.evaluateJavaScript(js)
    }
}

struct PlayerView: View {
    let game: FlashGame
    @Environment(\.dismiss) private var dismiss
    
    @State private var showGamepad = false
    @StateObject private var controller = PlayerController()

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if let url = game.fileURL {
                RufflePlayerView(swfURL: url, controller: controller)
                    .ignoresSafeArea()
            } else {
                ContentUnavailableView(
                    "Error de archivo",
                    systemImage: "exclamationmark.triangle",
                    description: Text("No se pudo localizar el archivo del juego.")
                )
            }
            
            if showGamepad {
                GamepadOverlay(controller: controller)
            }
            
            // Botón de Cerrar (Mantenido arriba a la izquierda, pero más sutil)
            VStack {
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.white.opacity(0.6))
                            .padding(12)
                            .background(Circle().fill(Color.black.opacity(0.3)))
                    }
                    .padding(.leading, 30)
                    .padding(.top, 15)
                    Spacer()
                }
                Spacer()
            }
            
            // Botón del Gamepad movido a la franja negra inferior derecha
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: { 
                        withAnimation { showGamepad.toggle() } 
                    }) {
                        Image(systemName: showGamepad ? "gamecontroller.fill" : "gamecontroller")
                            .font(.system(size: 22, weight: .bold))
                            // Si está activo es verde tenue, si no, blanco transparente
                            .foregroundColor(showGamepad ? .green.opacity(0.7) : .white.opacity(0.5))
                            .padding(12)
                            .background(Circle().fill(Color.black.opacity(0.3)))
                    }
                    .padding(.trailing, 40)
                    .padding(.bottom, 15)
                }
            }
        }
        .persistentSystemOverlays(.hidden)
        // FORZAR MODO HORIZONTAL AL ENTRAR
        .onAppear {
            if #available(iOS 16.0, *) {
                guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
                windowScene.requestGeometryUpdate(.iOS(interfaceOrientations: .landscape))
            }
        }
        // DEVOLVER AL MODO VERTICAL AL SALIR
        .onDisappear {
            if #available(iOS 16.0, *) {
                guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
                windowScene.requestGeometryUpdate(.iOS(interfaceOrientations: .portrait))
            }
        }
    }
}

// MARK: - Diseño del Gamepad Inteligente y Transparente
struct GamepadOverlay: View {
    @ObservedObject var controller: PlayerController
    
    @State private var opacity: Double = 0.5
    @State private var hideTimer: Timer?
    
    var body: some View {
        VStack {
            Spacer()
            HStack {
                // Cruceta Direccional
                VStack(spacing: 5) {
                    GameButton(icon: "arrowup", key: "ArrowUp", code: "ArrowUp", keyCode: 38, controller: controller, notifyInteraction: resetTimer)
                    HStack(spacing: 35) {
                        GameButton(icon: "arrowleft", key: "ArrowLeft", code: "ArrowLeft", keyCode: 37, controller: controller, notifyInteraction: resetTimer)
                        GameButton(icon: "arrowright", key: "ArrowRight", code: "ArrowRight", keyCode: 39, controller: controller, notifyInteraction: resetTimer)
                    }
                    GameButton(icon: "arrowdown", key: "ArrowDown", code: "ArrowDown", keyCode: 40, controller: controller, notifyInteraction: resetTimer)
                }
                .padding(.leading, 50)
                .padding(.bottom, 30)
                
                Spacer()
                
                // Botones de Acción
                HStack(spacing: 15) {
                    GameButton(text: "SPC", key: " ", code: "Space", keyCode: 32, controller: controller, width: 70, notifyInteraction: resetTimer)
                    GameButton(text: "ENT", key: "Enter", code: "Enter", keyCode: 13, controller: controller, width: 70, notifyInteraction: resetTimer)
                }
                .padding(.trailing, 100) // Desplazado para que no choque con el botón de ocultar mando
                .padding(.bottom, 40)
            }
        }
        .opacity(opacity)
        .onAppear { resetTimer() }
    }
    
    // Función que devuelve el brillo y programa el auto-ocultado
    func resetTimer() {
        withAnimation { opacity = 0.6 } // Brillo al tocar
        hideTimer?.invalidate()
        hideTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { _ in
            withAnimation(.easeInOut(duration: 1.5)) {
                opacity = 0.05 // Se vuelve un fantasma casi invisible
            }
        }
    }
}

// MARK: - Botones del Gamepad (Efecto Cristal)
struct GameButton: View {
    var icon: String? = nil
    var text: String? = nil
    let key: String
    let code: String
    let keyCode: Int
    @ObservedObject var controller: PlayerController
    var width: CGFloat = 60
    var notifyInteraction: () -> Void
    
    @State private var isPressed = false
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18)
                // Color super transparente
                .fill(isPressed ? Color.white.opacity(0.2) : Color.white.opacity(0.02))
                .frame(width: width, height: 60)
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(Color.white.opacity(0.15), lineWidth: 1.5)
                )
            
            if let icon = icon {
                Image(systemName: icon).foregroundColor(Color.white.opacity(0.5)).font(.title2)
            } else if let text = text {
                Text(text).foregroundColor(Color.white.opacity(0.5)).font(.headline)
            }
        }
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    notifyInteraction() // Enciende el brillo
                    if !isPressed {
                        isPressed = true
                        controller.simulateKey(key: key, code: code, keyCode: keyCode, isDown: true)
                        // Pequeña vibración háptica al tocar
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    }
                }
                .onEnded { _ in
                    notifyInteraction()
                    isPressed = false
                    controller.simulateKey(key: key, code: code, keyCode: keyCode, isDown: false)
                }
        )
    }
}

// MARK: - Reproductor con Custom Scheme
struct RufflePlayerView: UIViewRepresentable {
    let swfURL: URL
    @ObservedObject var controller: PlayerController

    func makeCoordinator() -> Coordinator {
        Coordinator(swfURL: swfURL)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let handler = LocalSchemeHandler()
        config.setURLSchemeHandler(handler, forURLScheme: "flashbox")

        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.isScrollEnabled = false
        web.scrollView.bounces = false 

        controller.webView = web

        if let url = URL(string: "flashbox://localhost/player.html") {
            web.load(URLRequest(url: url))
        }

        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        let swfURL: URL

        init(swfURL: URL) {
            self.swfURL = swfURL
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            do {
                let cssJS = "var style = document.createElement('style'); style.innerHTML = 'body, html { margin: 0; padding: 0; width: 100vw; height: 100vh; overflow: hidden; background-color: black; }'; document.head.appendChild(style);"
                webView.evaluateJavaScript(cssJS)

                let data = try Data(contentsOf: swfURL)
                let b64 = data.base64EncodedString()
                let js = "window.loadFlashBase64 && window.loadFlashBase64('\(b64)');"
                webView.evaluateJavaScript(js)
            } catch {
                print("Error al leer el SWF: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - Manejador del Servidor Falso
class LocalSchemeHandler: NSObject, WKURLSchemeHandler {
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else { return }
        let fileName = url.lastPathComponent
        var fileURL: URL?

        if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Resources/Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Ruffle") {
            fileURL = bundleURL
        } else if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil) {
            fileURL = bundleURL
        }

        if let validFileURL = fileURL, let data = try? Data(contentsOf: validFileURL) {
            let mimeType = UTType(filenameExtension: validFileURL.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            let finalMimeType = validFileURL.pathExtension.lowercased() == "wasm" ? "application/wasm" : mimeType

            let response = HTTPURLResponse(
                url: url, statusCode: 200, httpVersion: nil,
                headerFields: ["Content-Type": finalMimeType, "Access-Control-Allow-Origin": "*"]
            )!
            urlSchemeTask.didReceive(response)
            urlSchemeTask.didReceive(data)
            urlSchemeTask.didFinish()
        } else {
            let response = HTTPURLResponse(url: url, statusCode: 404, httpVersion: nil, headerFields: nil)!
            urlSchemeTask.didReceive(response)
            urlSchemeTask.didFinish()
        }
    }
    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) { }
}