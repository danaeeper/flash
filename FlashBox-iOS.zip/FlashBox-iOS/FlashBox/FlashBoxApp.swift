import SwiftUI

@main
struct FlashBoxApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
