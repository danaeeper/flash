#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/FlashBox/Resources/Ruffle"
mkdir -p "$DEST"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "Buscando la última versión de Ruffle Web..."
URL="$(python3 - <<'PY'
import json, urllib.request

url = 'https://api.github.com/repos/ruffle-rs/ruffle/releases/latest'
req = urllib.request.Request(url, headers={'User-Agent': 'FlashBox-builder'})
with urllib.request.urlopen(req) as r:
    data = json.load(r)

asset = next((a for a in data.get('assets', []) if a['name'].endswith('-web-selfhosted.zip')), None)
if not asset:
    raise SystemExit('No se encontró el asset web-selfhosted en la release de Ruffle.')

print(asset['browser_download_url'])
PY
)"

echo "Descargando: $URL"
curl -L --fail --silent --show-error "$URL" -o "$TMP/ruffle.zip"

echo "Descomprimiendo archivos de Ruffle..."
unzip -q "$TMP/ruffle.zip" -d "$TMP/unzip"

# Copia los archivos JS y WASM al lado de player.html
cp -R "$TMP/unzip"/* "$DEST/"

echo "Ruffle instalado correctamente en $DEST"