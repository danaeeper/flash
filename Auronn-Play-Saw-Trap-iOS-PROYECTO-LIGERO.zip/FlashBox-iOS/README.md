# Auronn Play Saw Trap iOS

Este proyecto no incluye el SWF grande dentro del repositorio. GitHub limita a 25 MiB los archivos subidos desde el navegador.

## Preparación única

1. Crea una Release en este repositorio con la etiqueta `game-assets`.
2. Sube a esa Release el archivo `auron_play_jig_trap.swf`.
3. No lo subas a la carpeta normal del repositorio.
4. Después copia esta carpeta `FlashBox-iOS` al repositorio.
5. Ejecuta Actions > Build Auronn Play Saw Trap IPA.

El workflow descargará automáticamente el SWF desde la Release y construirá el IPA.
