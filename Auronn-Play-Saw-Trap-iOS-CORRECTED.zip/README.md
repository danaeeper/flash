# Auronn Play Saw Trap — iOS build

This package builds the original Auronn Play Saw Trap SWF as an iOS AIR application using HARMAN AIR SDK 51.4.1.1 and the original iOS-capable ANEs.

The SWF is downloaded automatically from the existing GitHub Release asset, so the large SWF does not need to be committed to the repository.

## Required GitHub Actions secrets

Create these repository secrets before running the Action:

- `IOS_P12_BASE64` = base64 of the Apple Developer `.p12` certificate that matches the provisioning profile.
- `IOS_P12_PASSWORD` = password of that `.p12`.
- `IOS_MOBILEPROVISION_BASE64` = base64 of `Auron iOS App Development (ios).mobileprovision`.

The workflow verifies the Bundle ID, Team ID, and that the P12 certificate is actually allowed by the provisioning profile before building.

## Bundle ID

`com.auron.app`

This exactly matches the provisioning profile generated for Auron.

## Build

GitHub → Actions → Build Auronn Play Saw Trap → Run workflow.

The output artifact is `Auronn-Play-Saw-Trap-IPA`.

## Important

The build is configured for `ipa-test` and includes the five ANEs declared by the original AIR application. AIR's official documentation requires the provisioning profile for iOS packaging and requires `-extdir` when packaging applications that use ANEs.

A successful GitHub build proves that the IPA was packaged and signed correctly. It cannot prove game runtime behavior on a physical iPhone until the IPA is actually launched there. The first device test is therefore still necessary.
