#!/bin/bash
set -euo pipefail
xmllint --noout game/application.xml
grep -q '<id>com.auron.app</id>' game/application.xml
for f in ane/*.ane; do unzip -t "$f" >/dev/null; done
echo 'Project structure OK.'
